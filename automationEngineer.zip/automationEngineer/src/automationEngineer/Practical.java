package automationEngineer;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.DesiredCapabilities;

public class Practical {

	public static void main(String[] args) 
	{
				System.setProperty("webdriver.chrome.driver","drivers//chromedriver.exe");
				ChromeOptions o= new ChromeOptions();
			    o.addArguments("--incognito");
			    DesiredCapabilities c = DesiredCapabilities.chrome();
			    c.setCapability(ChromeOptions.CAPABILITY, o);
			    WebDriver driver = new ChromeDriver(o);
			    driver.get("https://cc.healthrecoverysolutions.com/login");
			    
			    //did not write assertions because unable to login into the application
	}

}
