package automationEngineer;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class AllAdmins {

	public static void main(String[] args) 
	{
		System.setProperty("webdriver.chrome.driver", "drivers//chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("url");
		driver.manage().window().maximize();
		Select s=new Select(driver.findElement(By.className("admin")));
		List <WebElement> list = s.getOptions();
		System.out.println(list.size());
		Set <String> listNames =new HashSet <String> (list.size());
		for(WebElement w: list)
		{
			listNames.add(w.getText().trim());
		}
		if(list.size()== listNames.size())
	        System.out.println("2 lists are equal");
	    else
	    	System.out.println("2 lists are not equal");
			
		
	}

}
