package automationEngineer;

public class Answers {

	public static void main(String[] args) 
	{
		/*
		 What actions for elements do you know?
		Ans: in selenium, we have double click, right click and move to element, drag and drop, 
		
		How to get an element using Selenium?
		Ans: Using findelement we can get the element and if you want to get the text of an element then we can use gettext method
		if you want to find the value of an attribute then we can use getAttribute method
		
		How to work with select in selenium
		Ans: we can use select to select the dropdowns and for multi values in the multi selection box
		
		What actions can be applied to an element using selenium
		Ans: in selenium, we can apply actopns on elements using  double click, right click and move to element, drag and drop, 
		  
		  Does selenium support drag and drop?
		Ans: yes selenium supports drag and drop
		
		Does selenium support file uploads? How?
		Ans: No selenium will support file uploads but we can use java robot or autoit for file uploads
		
		

		  
		  
		  
		  
		  
		  
		  
		 */
	}

}
